<?php
// auth_middleware.php - JWT Authentication Middleware
require_once __DIR__ . '/../db.php'; // Add this line to include the config file
require_once __DIR__ . '/../jwt_token/jwt_helper.php'; // Include JWT helper

function authenticateJWT($required_role = null) {
    $jwt = JWTHelper::getJWTFromHeader();
    
    if (!$jwt) {
        http_response_code(401);
        echo json_encode(array("message" => "No token provided", "status" => false));
        exit;
    }
    
    // ✅ Check if token is blacklisted
    if (JWTHelper::isTokenBlacklisted($jwt)) {
        http_response_code(401);
        echo json_encode(array("message" => "Token has been revoked", "status" => false));
        exit;
    }
    
    $payload = JWTHelper::validateJWT($jwt, JWT_SECRET);
    
    if (!$payload) {
        http_response_code(401);
        echo json_encode(array("message" => "Invalid or expired token", "status" => false));
        exit;
    }
    
    // Check if user should be automatically logged out due to inactivity
    if (isset($payload['user_id'])) {
        if (JWTHelper::checkAndLogoutInactiveUser($jwt, $payload['user_id'])) {
            http_response_code(401);
            echo json_encode(array(
                "message" => "Session expired due to inactivity. Please login again.", 
                "status" => false,
                "auto_logout" => true
            ));
            exit;
        }
    }
    
    // ✅ Check role(s) if specified
    if ($required_role) {
        $userRole = $payload['role'] ?? null;

        // If required_role is a string, convert to array
        $allowedRoles = is_array($required_role) ? $required_role : [$required_role];

        if (!in_array($userRole, $allowedRoles)) {
            http_response_code(403);
            echo json_encode(array("message" => "Insufficient permissions", "status" => false));
            exit;
        }
    }
    
    // ✅ Update user activity on successful authentication
    if (isset($payload['user_id'])) {
        JWTHelper::updateUserActivity($payload['user_id']);
    }
    
    return $payload; // Return user data from token
}

function getCurrentUser() {
    $jwt = JWTHelper::getJWTFromHeader();
    if ($jwt) {
        return JWTHelper::validateJWT($jwt, JWT_SECRET);
    }
    return null;
}
?>
