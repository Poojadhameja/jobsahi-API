<?php
// update_activity.php - Update user activity timestamp
require_once '../cors.php';

// Authenticate user
$current_user = authenticateJWT();

if (!$current_user) {
    http_response_code(401);
    echo json_encode(array("message" => "Authentication required", "status" => false));
    exit;
}

// Update user's last activity
$user_id = $current_user['user_id'];
if (JWTHelper::updateUserActivity($user_id)) {
    http_response_code(200);
    echo json_encode(array(
        "message" => "Activity updated successfully",
        "status" => true
    ));
} else {
    http_response_code(500);
    echo json_encode(array(
        "message" => "Failed to update activity",
        "status" => false
    ));
}
?>
