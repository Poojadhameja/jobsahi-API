<?php
// jwt_helper.php - JWT Helper Functions
class JWTHelper {
    private static function base64UrlEncode($data) {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }
    
    private static function base64UrlDecode($data) {
        return base64_decode(str_pad(strtr($data, '-_', '+/'), strlen($data) % 4, '=', STR_PAD_RIGHT));
    }
    
    public static function generateJWT($payload, $secret = null, $algorithm = 'HS256') {
        if ($secret === null) {
            $secret = JWT_SECRET;
        }
        
        $header = json_encode(['typ' => 'JWT', 'alg' => $algorithm]);
        $payload = json_encode($payload);
        
        $headerEncoded = self::base64UrlEncode($header);
        $payloadEncoded = self::base64UrlEncode($payload);
        
        $signature = hash_hmac('sha256', $headerEncoded . '.' . $payloadEncoded, $secret, true);
        $signatureEncoded = self::base64UrlEncode($signature);
        
        return $headerEncoded . '.' . $payloadEncoded . '.' . $signatureEncoded;
    }
    
    public static function validateJWT($jwt, $secret = null) {
        if ($secret === null) {
            $secret = JWT_SECRET;
        }
        
        $parts = explode('.', $jwt);
        if (count($parts) !== 3) {
            return false;
        }
        
        list($headerEncoded, $payloadEncoded, $signatureEncoded) = $parts;
        
        $signature = self::base64UrlDecode($signatureEncoded);
        $expectedSignature = hash_hmac('sha256', $headerEncoded . '.' . $payloadEncoded, $secret, true);
        
        if (!hash_equals($signature, $expectedSignature)) {
            return false;
        }
        
        $payload = json_decode(self::base64UrlDecode($payloadEncoded), true);
        
        // Check expiration
        if (isset($payload['exp']) && $payload['exp'] < time()) {
            return false;
        }
        
        // Check user activity (7 days inactivity check)
        if (isset($payload['user_id'])) {
            if (!self::checkUserActivity($payload['user_id'])) {
                return false;
            }
        }
        
        return $payload;
    }
    
    public static function getJWTFromHeader() {
        $headers = getallheaders();
        if (!$headers || !isset($headers['Authorization'])) {
            return null;
        }
        
        $authHeader = $headers['Authorization'];
        if (preg_match('/Bearer\s+(.*)$/i', $authHeader, $matches)) {
            return $matches[1];
        }
        
        return null;
    }
    
    public static function verifyJWT($jwt, $secret = null) {
        return self::validateJWT($jwt, $secret);
    }
    
    // ✅ Blacklist token functions
    public static function blacklistToken($jwt, $user_id = null) {
        global $conn;
        
        if (!$jwt) {
            return false;
        }
        
        // Create hash of the token for storage
        $token_hash = hash('sha256', $jwt);
        
        // Get token expiration from payload
        $payload = self::validateJWT($jwt, JWT_SECRET);
        $expires_at = isset($payload['exp']) ? date('Y-m-d H:i:s', $payload['exp']) : null;
        
        // Check if token is already blacklisted
        $check_sql = "SELECT id FROM blacklisted_tokens WHERE token_hash = ?";
        if ($check_stmt = mysqli_prepare($conn, $check_sql)) {
            mysqli_stmt_bind_param($check_stmt, "s", $token_hash);
            mysqli_stmt_execute($check_stmt);
            $result = mysqli_stmt_get_result($check_stmt);
            
            if (mysqli_num_rows($result) > 0) {
                mysqli_stmt_close($check_stmt);
                return true; // Already blacklisted
            }
            mysqli_stmt_close($check_stmt);
        }
        
        // Insert into blacklist
        $insert_sql = "INSERT INTO blacklisted_tokens (token_hash, user_id, expires_at) VALUES (?, ?, ?)";
        if ($insert_stmt = mysqli_prepare($conn, $insert_sql)) {
            mysqli_stmt_bind_param($insert_stmt, "sis", $token_hash, $user_id, $expires_at);
            $success = mysqli_stmt_execute($insert_stmt);
            mysqli_stmt_close($insert_stmt);
            return $success;
        }
        
        return false;
    }
    
    public static function isTokenBlacklisted($jwt) {
        global $conn;
        
        if (!$jwt) {
            return true; // No token = considered blacklisted
        }
        
        $token_hash = hash('sha256', $jwt);
        
        $sql = "SELECT id FROM blacklisted_tokens WHERE token_hash = ?";
        if ($stmt = mysqli_prepare($conn, $sql)) {
            mysqli_stmt_bind_param($stmt, "s", $token_hash);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            
            $is_blacklisted = mysqli_num_rows($result) > 0;
            mysqli_stmt_close($stmt);
            return $is_blacklisted;
        }
        
        return false;
    }
    
    // Clean up expired blacklisted tokens (can be called periodically)
    public static function cleanupExpiredBlacklistedTokens() {
        global $conn;
        
        $sql = "DELETE FROM blacklisted_tokens WHERE expires_at IS NOT NULL AND expires_at < NOW()";
        if ($stmt = mysqli_prepare($conn, $sql)) {
            mysqli_stmt_execute($stmt);
            $affected_rows = mysqli_stmt_affected_rows($stmt);
            mysqli_stmt_close($stmt);
            return $affected_rows;
        }
        
        return 0;
    }
    
    // Check if user has been active within 7 days
    public static function checkUserActivity($user_id) {
        global $conn;
        
        $sql = "SELECT last_activity FROM users WHERE id = ?";
        if ($stmt = mysqli_prepare($conn, $sql)) {
            mysqli_stmt_bind_param($stmt, "i", $user_id);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            
            if ($row = mysqli_fetch_assoc($result)) {
                $last_activity = $row['last_activity'];
                
                // If no activity recorded, consider as inactive
                if (!$last_activity) {
                    mysqli_stmt_close($stmt);
                    return false;
                }
                
                // Check if last activity was within 10 seconds
                $ten_seconds_ago = time() - 10;
                $last_activity_timestamp = strtotime($last_activity);
                
                mysqli_stmt_close($stmt);
                return $last_activity_timestamp >= $ten_seconds_ago;
            }
            
            mysqli_stmt_close($stmt);
        }
        
        return false;
    }
    
    // Update user's last activity timestamp
    public static function updateUserActivity($user_id) {
        global $conn;
        
        $sql = "UPDATE users SET last_activity = NOW() WHERE id = ?";
        if ($stmt = mysqli_prepare($conn, $sql)) {
            mysqli_stmt_bind_param($stmt, "i", $user_id);
            $success = mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);
            return $success;
        }
        
        return false;
    }
    
    // Check if user should be automatically logged out due to inactivity
    public static function checkAndLogoutInactiveUser($jwt, $user_id) {
        if (!self::checkUserActivity($user_id)) {
            // User is inactive, blacklist the token
            self::blacklistToken($jwt, $user_id);
            return true; // User should be logged out
        }
        return false; // User is still active
    }
}
?>